import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ProductService } from '../datashare.service';

@Component({
  selector: 'app-name-editor',
  templateUrl: './name-editor.component.html',
  styleUrls: ['./name-editor.component.css'],
})
export class NameEditorComponent implements OnInit {
  // bioSection = new FormGroup({
  //   firstName: new FormControl(''),
  //   lastName: new FormControl(''),
  //   age: new FormControl(''),
  //   stackDetails: new FormGroup({
  //     stack: new FormControl(''),
  //     experience: new FormControl(''),
  //   }),
  //   address: new FormGroup({
  //     country: new FormControl(''),
  //     city: new FormControl(''),
  //   }),
  // });

  bioSection = this.fb.group({
    firstName: [''],
    lastName: [''],
    age: [''],
    stackDetails: this.fb.group({
      stack: [''],
      experience: [''],
    }),
    address: this.fb.group({
      country: [''],
      city: [''],
    }),
  });

  constructor(
    private productService: ProductService,
    private fb: FormBuilder
  ) {}
  ngOnInit() {}
  callingFunction() {
    this.productService.setProduct(this.bioSection.value);
    console.log('name-editor data', this.bioSection.value);
    this.productService.nextMessage('Second message');
    // this.productService.nextMessage(this.productService);
  }
}
