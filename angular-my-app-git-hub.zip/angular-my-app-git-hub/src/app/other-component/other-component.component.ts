import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ProductService } from '../datashare.service';

@Component({
  selector: 'app-other-component',
  templateUrl: './other-component.component.html',
  styleUrls: ['./other-component.component.css'],
})
export class OtherComponentComponent implements OnInit {
  recievedata: any;

  childArray = [{ name: 'sasika', mark: '25' }];

  @Input() item = ''; // decorate the property with @Input()

  @Output() newItemEvent = new EventEmitter<string>();

  addNewItem(value: string) {
    this.newItemEvent.emit(value);
  }

  updateList(obj: any) {
    this.childArray.push(obj);
  }

  constructor(private prodService: ProductService) {}
  ngOnInit() {
    this.prodService.sharedMessage.subscribe(
      (message) => (this.recievedata = message)
    );
  }
}
