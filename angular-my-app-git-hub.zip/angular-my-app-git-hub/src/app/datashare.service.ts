import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DataModel } from './model.interface';

@Injectable()
export class ProductService {
  public initialState = {
    address: { country: 'Test', city: 'Test' },
    age: 'Test',
    firstName: 'Test',
    lastName: 'Test',
    stackDetails: { stack: 'Test', experience: 'Test' },
  };

  private message = new BehaviorSubject(this.initialState);
  sharedMessage = this.message.asObservable();

  prodservice: any;
  constructor() {}

  nextMessage(message: any) {
    this.message.next(message);
  }

  setProduct(product: any) {
    this.prodservice = product;
    console.log('service data', this.prodservice);
  }
}
