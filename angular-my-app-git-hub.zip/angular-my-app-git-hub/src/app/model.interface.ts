export interface DataModel {
  address: { country: string; city: string };
  age: string;
  firstName: string;
  lastName: string;
  stackDetails: { stack: string; experience: string };
}
