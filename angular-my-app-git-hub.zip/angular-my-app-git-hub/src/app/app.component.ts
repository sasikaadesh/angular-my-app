import { Component, ViewChild } from '@angular/core'; // First, import Input
import { OtherComponentComponent } from './other-component/other-component.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  @ViewChild(OtherComponentComponent) viewdata!: OtherComponentComponent;

  title = 'my-app';
  currentItem = 'From parent component';

  inputObj = { name: '', mark: '' };

  items = ['item1', 'item2', 'item3', 'item4'];

  addItem(newItem: string) {
    this.items.push(newItem);
  }

  TransferData(name: any, mark: any) {
    this.inputObj = { name: name, mark: mark };
    this.viewdata.updateList(this.inputObj);
  }
}
